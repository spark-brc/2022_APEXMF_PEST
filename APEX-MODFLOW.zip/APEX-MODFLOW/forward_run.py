import os
from datetime import datetime
import pyemu
from apexmf_pst_utils import extract_month_str, extract_depth_to_water


wd = os.getcwd()
os.chdir(wd)
print(wd)

# file path
rch_file = 'SITE75.RCH'
# reach numbers that are used for calibration
subs = [12, 57, 75]

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'+ ')
print(time + ' |  modifying parameters...')
print(30*'+ ' + '\n')

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'+ ')
print(time + ' |  running model...')
print(30*'+ ' + '\n')

pyemu.os_utils.run('apexmf.exe', cwd='.')

time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 50*'+ ')
print(time + ' | simulation successfully completed | extracting simulated values...')
print(50*'+ ' + '\n')
extract_month_str(rch_file, subs, '1/1/2002', '1/1/2002', '12/31/2002')
extract_depth_to_water([5895, 6273], '1/1/2002', '12/31/2002')


